#include <string>
#include <iostream>
#include <sstream>
#include <limits.h>
#include <vector>
#include <map>
#include <unordered_set>
#include "Conhash.h"

// int main() {

// 	Hasher hasher;

// 	long hashVal = hasher.getHashVal("127.0.0.1:8000");
// 	std::cout << hashVal << std::endl;

// 	hashVal = hasher.getHashVal("127.0.0.1:8001");
// 	std::cout << hashVal << std::endl;

// 	hashVal = hasher.getHashVal("127.0.0.1:8002");
// 	std::cout << hashVal << std::endl;
	
// }